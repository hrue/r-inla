setwd("~/Desktop/Daily/presentation/2015-10-01 Shiny and RGtk2/")

library(shiny)

runApp("HelloShiny")

runApp("Layout", display.mode = "showcase")

runApp("Gridlayout", display.mode = "showcase")

runApp("Tabsets", display.mode = "showcase")

runApp("Navlist", display.mode = "showcase")

runApp("ControlWidgets", display.mode = "showcase")

runApp("ActionButton", display.mode = "showcase")

runApp("RenderText", display.mode = "showcase")

runApp("RenderPrint", display.mode = "showcase")

runApp("RenderTable", display.mode = "showcase")

runApp("RINLA_step1", display.mode = "showcase")

runApp("RINLA_step2", display.mode = "showcase")

runApp("RINLA_step3", display.mode = "showcase")

runApp("RINLA_step4", display.mode = "showcase")

runApp("RINLA_step5", display.mode = "showcase")

runApp("RINLA_step6", display.mode = "showcase")

runApp("RINLA_step7", display.mode = "showcase")

runApp("RINLA_stepf", display.mode = "showcase")

runApp("meta4diag", display.mode = "showcase")

