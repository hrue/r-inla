library(shiny)
library(INLA)

shinyServer(function(input, output) {
})



