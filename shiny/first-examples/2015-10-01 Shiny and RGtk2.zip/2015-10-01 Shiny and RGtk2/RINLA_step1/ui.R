library(shiny)

shinyUI(navbarPage("A Simple R-INLA tutorial",
                   tabPanel("R-INLA"),
                   tabPanel("SPDE")
)
)