##############################################################
## Measurement error in GLMMs with INLA (2013)
## by S. Muff, A. Riebler, H. Rue, P. Saner and  L. Held
##
## r-inla code for Section 5.1
## Inbreeding in Swiss ibex populations
##############################################################

library(INLA)
# > inla.version()
#
#
# INLA build date .........: Sat Jul 13 09:42:38 CEST 2013
# INLA hgid ...............: hgid: 93d466d9eaab  date: Sat Jul 13 09:42:00 2013 +0200
# INLA-program hgid .......: hgid: ef654eda81ec  date: Thu Jul 11 01:03:19 2013 +0200
# Maintainers .............: Havard Rue <hrue@math.ntnu.no>
#   : Finn Lindgren <finn.lindgren@gmail.com>
#   : Daniel Simpson <dp.simpson@gmail.com>
#   : Andrea Riebler <andrea.riebler@math.ntnu.no>
#   Web-page ................: http://www.r-inla.org
# Email support ...........: help@r-inla.org
# : r-inla-discussion-group@googlegroups.com
# Source-code .............: http://inla.googlecode.com

data <- read.table("ibex_data4supp.txt", header=T)
attach(data)

prior.beta <- c(0, 0.0001)
prior.prec.x <- c(1.194, 0.00085)
prior.prec.y <- c(0.903, 0.0014)
prior.prec.u <- c(8.5, 7.5)

# initial values (mean of prior)
prec.x = 1.194/0.00085
prec.y = 0.903/0.0014
prec.u = 1

formula <- y ~ f(w, model = "mec", scale = error.prec, values=w, hyper = list(
  beta = list(
    param = prior.beta,
    fixed = FALSE
    ),
  prec.u = list(
    param = prior.prec.u,
    initial = log(prec.u),
    fixed = FALSE
    ),
  prec.x = list(
    param = prior.prec.x,
    initial = log(prec.x),
    fixed = FALSE
    ),
  mean.x = list(
    initial = 0,
    fixed = TRUE
    )
  )
) + z1 + z2 + z3 + z4

r <- inla(formula, data = data.frame(y, w, z1, z2, z3, z4, error.prec),
         family = "gaussian",
         control.family = list(
             hyper = list(
                prec = list(param = prior.prec.y,
                         initial = log(prec.y),
                         fixed = FALSE
                )
             )
          ),
         control.fixed = list(
           mean.intercept = prior.beta[1],
           prec.intercept = prior.beta[2],
           mean = prior.beta[1],
           prec = prior.beta[2]
         )
    )

r<-inla.hyperpar(r, dz = 0.5, diff.logdens = 20)

summary(r)
plot(r)


