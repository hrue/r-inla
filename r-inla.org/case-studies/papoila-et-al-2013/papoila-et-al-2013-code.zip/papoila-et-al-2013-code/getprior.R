###############################################################################
## Functions to derive prior distributions, based on the paper
##
## "Scaling intrinsic Gaussian Markov random field priors in spatial
## modelling" by Sorbye and Rue, 2013.
##
## Author: Andrea Riebler <andrea *.* riebler @ math *.* ntnu *.* no>
##
## Date: 19/07/2013
###############################################################################
## Function to get the structure matrix for the RW1
##
## Argument:
## n - length of the random walk
rw1 = function(n) {
    ## RW1
    L = matrix(0, n, n)
    for(i in 2:n) {
        L[c(i-1, i), i] = c(-1, 1)
    }
    Q = L %*% t(L)
    return (Q)
}

## ... and RW2
rw2 = function(n) {
    R = rw1(n)
    R = R[-c(1, n), ]
    Q = t(R) %*% R
    return (Q)
}

## get reference standard deviation derived by taking
## the geometric mean from the marginal standard deviations.
##
## Argument:
## Q - Structure matrix of the IGMRF
get.refSD <- function(Q){

    require(MASS)
    ## get the generalized inverse 
    gi <- ginv(Q)
    ## the marginal variances are on its diagonal
    mvar <- diag(gi)
    ## get the marginal standard deviations
    msd <- sqrt(mvar)
    ## compute the reference standard deviation as proposed
    ## by Sorbye and Rue 2013
    refSD <- exp(mean(log(msd)))

    return(refSD)
}

## read the data
library(gdata)
## give here the path to the data files
path <- ""
fem <- read.xls(paste(path, "female.xlsx", sep=""))
men <- read.xls(paste(path, "male.xlsx", sep=""))

# > head(fem)
#   region age_class population cases gender period
# 1      1         1         91    NA      0   1998
# 2      1         1         87    NA      0   1999
# 3      1         1         93    NA      0   2000
# 4      1         1         87    NA      0   2001
# 5      1         1         87    NA      0   2002
# 6      1         1        101    NA      0   2003

# > head(men)
#   region age_class population cases period gender
# 1      1         1         90    NA   1998      1
# 2      1         1         87    NA   1999      1
# 3      1         1         88    NA   2000      1
# 4      1         1         85    NA   2001      1
# 5      1         1         87    NA   2002      1
# 6      1         1         92    NA   2003      1

## cases equal to NA are zero
fem$cases[is.na(fem$cases)] <- 0
men$cases[is.na(men$cases)] <- 0

## remove first four age groups (0-20) and last age group (>85)
fem <- fem[!(fem$age_class %in% c(1,2,3,4,18)),]
men <- men[!(men$age_class %in% c(1,2,3,4,18)),]

## let the age groups start with 1 again
new_age <- as.factor(fem$age_class)
levels(new_age) <- 1:length(unique(fem$age_class))
fem$age_class <- new_age
men$age_class <- as.numeric(new_age)

## number of regions
R <- length(unique(men$region))
## number of age groups
I <- length(unique(men$age_class))
## number of periods
J <- length(unique(men$period))
## grid factor (is 5 as if have annual data but 5-year age-groups)
G <- 5
## number of cohorts
K <- G*(I-1)+J

## derive the reference standard deviation for the CAR modelling
library(INLA)

## for the CAR and interaction effect we need the graph information
graph_path <- "SUL4.graph"
## generate a neighbourhood matrix from the graph
pgraph <- as.matrix(inla.graph2matrix(graph_path))
pgraph <- -pgraph
## INLA sets the diagonal to 1, so we need to replace it by the number
## of neighbours a node has
infograph <- inla.read.graph(graph_path)
diag(pgraph) <- infograph$nnbs

## for the Type IV interaction (structured time - structured space) effect
## we take the Kronecker product of the corresponding precision matrices
gmrf.interact <- kronecker(pgraph, rw2(J))
## for the Type II interaction (structured time - unstructured space) effect
## we take the Kronecker product of the corresponding precision matrices
gmrf.interact2 <- kronecker(diag(R), rw2(J))

## derive the reference standard deviation for age, period, cohort, space
## and interation
refsd  <- c(age=get.refSD(rw2(I)), 
    period=get.refSD(rw2(J)),
    cohort=get.refSD(rw2(K)),
    space=get.refSD(pgraph),
    interact=get.refSD(gmrf.interact),
    interact2=get.refSD(gmrf.interact2))

## define different limits for upper standard deviation
U = c(0.5, 1, 5)

a <- 1
alpha <- 0.001
b <- matrix(NA, nrow=6, ncol=length(U))
for(i in 1:length(U)){
  b[1,i] <- U[i]^2*qgamma(alpha, shape=a,rate=1)/refsd["age"]^2
  b[2,i] <- U[i]^2*qgamma(alpha, shape=a,rate=1)/refsd["period"]^2
  b[3,i] <- U[i]^2*qgamma(alpha, shape=a,rate=1)/refsd["cohort"]^2
  b[4,i] <- U[i]^2*qgamma(alpha, shape=1,rate=1)/refsd["space"]^2
  b[5,i] <- U[i]^2*qgamma(alpha, shape=1,rate=1)/refsd["interact"]^2
  b[6,i] <- U[i]^2*qgamma(alpha, shape=1,rate=1)/refsd["interact2"]^2
}
rownames(b) <- c("age", "period", "cohort", "space", "interaction", "interaction2")
colnames(b) <- c("U = 0.5", "U=1", "U=5")

format(b, digits=5, nsmall=5)

# > format(b, digits=5, nsmall=5)
#              U = 0.5      U=1          U=5         
# age          "6.4548e-05" "2.5819e-04" "6.4548e-03"
# period       "1.8680e-04" "7.4719e-04" "1.8680e-02"
# cohort       "4.4417e-07" "1.7767e-06" "4.4417e-05"
# space        "4.6874e-04" "1.8750e-03" "4.6874e-02"
# interaction  "3.5006e-04" "1.4002e-03" "3.5006e-02"
# interaction2 "1.8680e-04" "7.4719e-04" "1.8680e-02"


## Following Fong, Rue and Wakefield (2009), Example 5.2 we choose a
## Ga(0.5, 0.00149) for the unstructured spacial effect.

