###############################################################################
## Functions to calculate a multivariate APC model with spatial component and
## Type II interaction
##
## Author: Andrea Riebler <andrea *.* riebler @ math *.* ntnu *.* no>
##
## Date: 19/07/2013
###############################################################################

## Try to combine multivariate APC analysis with spatial components

library(INLA)

source("defineConstraints.R")

agec <- c("[25,30[", "[30,35[", "[35,40[", "[40,45[", "[45,50[", "[50,55[", 
  "[55,60[", "[60,65[", "[65,70[", "[70,75[", "[75,80[", "[80,85[", "[85,+[")

## read the data
library(gdata)
## give here the path to the data files
path <- "../data/"
fem <- read.xls(paste(path, "female.xlsx", sep=""))
men <- read.xls(paste(path, "male.xlsx", sep=""))

# > head(fem)
#   region age_class population cases gender period
# 1      1         1         91    NA      0   1998
# 2      1         1         87    NA      0   1999
# 3      1         1         93    NA      0   2000
# 4      1         1         87    NA      0   2001
# 5      1         1         87    NA      0   2002
# 6      1         1        101    NA      0   2003

# > head(men)
#   region age_class population cases period gender
# 1      1         1         90    NA   1998      1
# 2      1         1         87    NA   1999      1
# 3      1         1         88    NA   2000      1
# 4      1         1         85    NA   2001      1
# 5      1         1         87    NA   2002      1
# 6      1         1         92    NA   2003      1

## assume that cases equal to NA are zero
fem$cases[is.na(fem$cases)] <- 0
men$cases[is.na(men$cases)] <- 0

## remove first four age groups (0-20) and last age group (>85)
fem <- fem[!(fem$age_class %in% c(1,2,3,4,18)),]
men <- men[!(men$age_class %in% c(1,2,3,4,18)),]

## let the age groups start with 1 again
new_age <- as.factor(fem$age_class)
levels(new_age) <- 1:length(unique(fem$age_class))
fem$age_class <- new_age
men$age_class <- as.numeric(new_age)

## set the period indices from 1 to 9
period_idx <- as.factor(men$period)
levels(period_idx) <- 1:9
period_idx <- as.numeric(period_idx)
men$period <- period_idx
fem$period <- period_idx

## number of regions
R <- length(unique(men$region))
## number of age groups
I <- length(unique(men$age_class))
## number of periods
J <- length(unique(men$period))
## grid factor (is 5 as if have annual data but 5-year age-groups)
G <- 5
## number of cohorts
K <- G*(I-1)+J

## data-vector (combine males and females for a coupled analysis)
y <- c(men$cases, fem$cases)
pop <- c(men$population, fem$population)

## gender-specific intercept (1 for males,  0 for females)
mu_male <- rep(c(1,0), each=I*J*R)
mu_female <- rep(c(0,1), each=I*J*R)

## age indices (it is the same for males and females
i <- c(men$age_class, fem$age_class )
## period indices 
j <- c(period_idx, period_idx)
## cohort indices
G <- 5
k <- G*(I - i) + j
z <- 1:(2*I*J*R)
## region indices
r <- c(men$region, fem$region)
## get the interaction indices defining an 
## interaction between period and region
interaction <- c()
for(s in 1:R){ 
    interaction <- c(interaction, rep(((s-1)*J + 1):(s*J), I))
}
interaction <- c(interaction, interaction)

## generate the dataset for INLA
data <- data.frame(y=y, E=pop, i=i, j=j, k=k, r_unstruc=r, r_struc=r, 
    interaction=interaction, mu_male=mu_male, mu_female=mu_female, z=z)

## indicator vector to mark male and female observations. This is necessary
## to assure that the same precision parameters are used for gender-specific 
## age-effects, say. 
replicate <- rep(c(1,2),each=I*J*R)

## Priors using U=0.5 and a=1 for all rw2 and a=25 for the CAR effect
## see getprior.R

#              U = 0.5      U=1          U=5         
# age          "6.4548e-05" "2.5819e-04" "6.4548e-03"
# period       "1.8680e-04" "7.4719e-04" "1.8680e-02"
# cohort       "4.4417e-07" "1.7767e-06" "4.4417e-05"
# space        "4.6874e-04" "1.8750e-03" "4.6874e-02"
# interaction  "3.5006e-04" "1.4002e-03" "3.5006e-02"
# interaction2 "1.8680e-04" "7.4719e-04" "1.8680e-02"

prec_age <- list(c(1, 0.00006), c(1,0.0003), c(1, 0.006), c(0.001, 0.001), c(1, 0.00005))
prec_period <- list(c(1, 0.0002), c(1, 0.0007), c(1,0.02), c(0.001, 0.001), c(1, 0.00005))
prec_cohort <- list(c(1, 0.0000004), c(1, 0.000002), c(1, 0.00004), c(0.001, 0.001), c(1, 0.00005))
prec_space <- list(c(1, 0.0005), c(1, 0.002), c(1, 0.05), c(0.001, 0.001), c(1, 0.00005))
prec_interact <- list(c(1, 0.0004), c(1, 0.001), c(1, 0.03), c(0.001, 0.001), c(1, 0.00005))
prec_interact2 <- list(c(1, 0.0001), c(1, 0.0007), c(1, 0.02), c(0.001, 0.001), c(1, 0.00005))

## Following Fong, Rue and Wakefield (2009), Example 5.2 we choose a
## Ga(0.5, 0.00149) for the unstructured spacial effect.
prec_uspace <- c(0.5, 0.00149)

## Define the linear combination for the relative risk of the best model apCSUI
lincomb_apCSUI <- c()

## relative age effects
for(l in 1:I) 
{
  idx <- rep(NA, 2*I)
  idx[c(l, I+l)] <- c(1,-1)
  lc <- inla.make.lincomb(mu_male=1, mu_female=-1, i=idx)
  names(lc) <- paste("diff_i.", inla.num(l, width=4), sep="")
  lincomb_apCSUI <- c(lincomb_apCSUI, lc)
}
## relative period effects
for(s in 1:J) 
{
  idx <- rep(NA, 2*J)
  idx[c(s, s+J)] <- c(1,-1)
  lc <- inla.make.lincomb(mu_male=1, mu_female=-1, j=idx)
  names(lc) <- paste("diff_j.", inla.num(s, width=4), sep="")
  lincomb_apCSUI <- c(lincomb_apCSUI, lc)
}
## adjusted relative risk (spatial-time effect)
count <- 0
for(m in 1:R){
    for(n in 1:J){
        count <- count + 1
        idx_unstruc <- rep(NA, R)
        idx_struc <- rep(NA, R)
        idx_interaction <- rep(NA, J*R)
        idx_interaction[count] <- 1 
        idx_struc[m] <- 1
        idx_unstruc[m] <- 1
        lc <- inla.make.lincomb( r_unstruc=idx_unstruc, r_struc=idx_struc, interaction=idx_interaction)
        names(lc) <- paste("diff_r.", inla.num(count, width=4), sep="")
        lincomb_apCSUI <- c(lincomb_apCSUI, lc)
    }
}

diag <- 1e-6
formula_sens <- list()
result_sens <- list()
for(m in 1:length(prec_period)){
  formula_sens[[m]] = y~f(i, model="rw2", hyper=list(prec=list(param=prec_age[[m]], initial=5.59)), 
	  replicate=replicate, constr=T, diagonal=diag) + 
      f(j, model="rw2", hyper=list(prec=list(param=prec_period[[m]], initial=8.72)), 
	  replicate=replicate,constr=T, diagonal=diag) +
      f(k, model="rw2", hyper=list(prec=list(param=prec_cohort[[m]], initial=10)), 
	   diagonal=diag,  constr=T) + 
      f(r_struc, model="besag", graph="SUL4.graph", 
	  hyper=list(prec=list(param=prec_space[[m]], initial=1.96)), 
	  diagonal=diag, constr=T) +
      f(r_unstruc, model="iid", hyper=list(prec=list(param=prec_uspace, initial=6.24)), 
	  diagonal=diag) + 
      f(interaction, model="generic0", Cmatrix=gmrf.interact2, extraconstr=extramInteract2, 
	  hyper=list(prec=list(param=prec_interact2[[m]], initial=2.48)), 
	  diagonal=diag, constr=F) +
      mu_male + mu_female - 1

  result_sens[[m]] <- inla(formula_sens[[m]], family="poisson", E=E, data=data, 
    quantile=c(0.025,0.5,0.975), verbose=TRUE, lincomb=lincomb_apCSUI,
    control.compute=list(dic=TRUE, cpo=TRUE, hyperpar=TRUE, mlik=TRUE),
    control.inla=list(strategy="gaussian"))  
}  

save(result_sens, formula_sens, file="results.RData")
