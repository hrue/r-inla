###############################################################################
## Functions to generate the plots from the paper
##
## Author: Andrea Riebler <andrea *.* riebler @ math *.* ntnu *.* no>
##
## Date: 19/07/2013
###############################################################################

library(INLA)
load("results.RData")

R <- 109
I <- 13
J <- 9

offset <- 0.1
cex.text <- 0.9

age <- c("[20-25[", "[25-30[", "[30-35[", "[35-40[", "[40-45[", "[45-50[", 
  "[50-55[", "[55-60[", "[60-65[", "[65-70[", "[70-75[", "[75-80[", "[80-85[")

########################## Figure 3 ######################

par(mfrow=c(1,2), las=1, mar=c(4,3.5,3,1), mgp=c(2.5,.8,0), cex.lab=1, cex.axis=cex.text)
## age effects
matplot(cbind(1,exp(result_sens[[1]]$summary.lincomb.derived[1:13,4:6])),
  col=c("grey60",rep(1,3)), lty=c(1,2,1,2), lwd=c(1,1,2,1),type="l", ylim=c(0.4,3), 
  main=expression("Age effects"),
  xlab="Age group", ylab="Average relative risk", xaxt="n", add=F)
polygon(c(1:13,13:1), c(exp(result_sens[[1]]$summary.lincomb.derived[1:13,4]),
  rev(exp(result_sens[[1]]$summary.lincomb.derived[1:13,6]))), border=F, col="grey80")
matplot(cbind(1,exp(result_sens[[1]]$summary.lincomb.derived[1:13,4:6])),
  col=c("grey60",rep(1,3)), lty=c(1,2,1,2), lwd=c(1,1,2,1), type="l", add=T)
axis(1, at=1:13, labels=F)
agelab_pos <- seq(1,13,by=2)
text(agelab_pos, par("usr")[3] - offset, srt = 45, adj = 1, labels=age[agelab_pos], xpd=TRUE, cex=cex.text)
## cohort effects
matplot(1998:2006, cbind(1,exp(result_sens[[1]]$summary.lincomb.derived[14:(13+J),4:6])),
  col=c("grey60",rep(1,3)), lty=c(1,2,1,2), lwd=c(1,1,2,1),type="l", ylim=c(0.4,3), 
  main=expression("Period effects"),
  xlab="Period", ylab="Average relative risk",  add=F)
polygon(c(1998:2006,2006:1998), c(exp(result_sens[[1]]$summary.lincomb.derived[14:(13+J),4]),
  rev(exp(result_sens[[1]]$summary.lincomb.derived[14:(13+J),6]))), border=F, col="grey80")
matplot(1998:2006, cbind(1,exp(result_sens[[1]]$summary.lincomb.derived[14:(13+J),4:6])),
  col=c("grey60",rep(1,3)), lty=c(1,2,1,2), lwd=c(1,1,2,1), type="l", add=T)

########################## Figure 4 ######################

library(maptools)     
library(RColorBrewer) 
library(classInt) 
portshp=readShapePoly("./ROR_6.shp", ID="ADJ_ID_ROR")

sp <- exp(result_sens[[1]]$summary.lincomb.derived[(I+J+1):(R*J+I+J), "0.5quant"])

sp_m <- matrix(NA, nrow=R, ncol=J)

count <- 0
for(m in 1:R){
  for(n in 1:J){
    count = count + 1
    sp_m[m,n] = sp[count]
  }
}
years <- 1998:2009
lines(c( -30421.26, -93376.41),c(-76023.07,  53353.90),col="orange", lwd=2)
par(mfrow=c(2,2), mar=c(0,0,3,0))
idx <- c(1,4,7, 9)
for(n in idx){
  portshp$sp <-  sp_m[,n]
  plotvar <- portshp@data$sp
  nclr <- 9
  plotclr <- brewer.pal(nclr,"Greys")
  class <- classIntervals(plotvar, nclr, style="fixed", 
  fixedBreaks=seq(min(sp), max(sp), length.out=10),dataPrecision=2) 
  colcode <- findColours(class, plotclr)
  plot(portshp)
  plot(portshp, col=colcode, add=T)
  title(main=paste(years[n]))
  if(n==9){legend("bottomright", horiz = FALSE, legend=names(attr(colcode, "table")),
  fill=attr(colcode, "palette"), bty="n", cex=.8)}
  #lines(c(-86698.58,-125837.7),c(-104875.3, -139139),col=1, lty=2, lwd=2)
  if(n==1){
  lines(c(-86698.58,-125837.7),c(-104875.3, -139139),col=1, lty=2, lwd=2)
  #arrows( -125837.7, -139139,-86698.58,-104875.3,col=1, lty=2, lwd=2, length=.1)
  text( -125837.7, -150539, "Lisbon", cex=1.2)}
}

########################## Figure 5 ######################

sp <- exp(result_sens[[1]]$summary.lincomb.derived[(I+J+1):(R*J+I+J), "0.5quant"])

ini<-seq(1,981,9)
ini
fini<-seq(9,981,9)
fini
spm<-matrix(NA,nrow=109,ncol=9)
for(i in 1:109){
spm[i,]<-sp[ini[i]:fini[i]]
}

offset <- 0.05
cc<-c(46,60,61)
plot(1:9,sp[1:9],"l",ylim=c(0.7,1.6),col="white",axes=F,xlab="Period",ylab="Adjusted relative risk")
for(j in 1:3){
i=cc[j]
lines(1:9,sp[ini[i]:fini[i]],lwd=2,lty=j)
}
legend("bottomleft",legend=c("Barreiro","Loures","Odivelas"),lty=1:3,bty="n",lwd=2)
axis(1,at=1:9,labels=F,las=2)
axis(2,las=2)
pos <- seq(1,9,by=1)
text(pos, par("usr")[3] - offset, srt = 45, adj = 1, labels=years[pos], xpd=TRUE, cex=cex.text)
box()

########################## Figure 6 ######################

weight <- c(7000, 7000, 7000, 7000, 7000, 7000, 7000, 6000, 5000, 4000, 3000, 2000, 1000)
weight <- weight/sum(weight) * 100000
fit <- result_sens[[1]]$summary.fitted.values[1:(2*I*J*R),"mean"]
count <- 0
newm <- c()
newf <- c()
# sum the mean fitted values over the age groups
for(n in 1:J){
    for(m in 1:R){
	count <- count + 1
	newm[count] <- sum(fit[data$r_struc==m & data$j==n & data$mu_male==1] *weight)
	newf[count] <- sum(fit[data$r_struc==m & data$j==n & data$mu_female==1] * weight)
  }
}
par(mar=c(4,4,0.5, 0.5), las=1)
plot(newm, xaxt="n", type="l", xlab="Counties by year", ylab="Age-standardized expected rate",ylim=c(0,60))
axis(1, at=seq(54.5, 927, by=109), labels=1998:2006)
abline(v=seq(1, 10*109, by=109), lty=2, col="grey60")
lines(newf, xaxt="n", type="l", xlab="Counties by year", ylab="Age-standardized expected rate", col="grey70")
axis(1, at=seq(54.5, 927, by=109), labels=1998:2006)
abline(v=seq(1, 10*109, by=109), lty=2, col="grey60")
legend("topright", c("Males", "Females"), lty=1, col=c(1, "grey70"), bg="white")

########################## Figure 7 ######################

library(INLA)

age <- c("[20-25[", "[25-30[", "[30-35[", "[35-40[", "[40-45[", "[45-50[", 
  "[50-55[", "[55-60[", "[60-65[", "[65-70[", "[70-75[", "[75-80[", "[80-85[")

layout(matrix(c(2,3,1,1), 2, 2, byrow = TRUE))

par(mar=c(4.5,5,4,0.5), las=1, cex.lab=1.5, cex.axis=1.4, cex.main=1.5)
n <- 109
res <- rep(NA,n)
for(m in 1:5){
  res <- as.matrix(cbind(res, result_sens[[m]]$summary.random$r_struc[, 5]))
}
res <- res[,-1]
res <- res[seq(1,109, by=4),]
len <- nrow(res)
res <- c(t(res))

x <- rep(c(0.8, 0.9, 1, 1.1, 1.2),len)
x <- x + rep((0:(len-1)), each=5)
x <- rep(x, each=1)

co <- c(1,"grey30", "grey45", "grey60", "grey75")
col= rep(rep(co, each=1), n/2)
plot(x, exp(res), col=col, pch=20, xaxt="n", 
  xlab="28 selected counties", ylab=expression(exp(u)),
  main="Structured spatial effect (selection)")
axis(1, at=1:len, labels=1:len)
abline(v=1:(len+1)-0.5, lty=2, col="grey40")

par(mar=c(4.5,5,4,0.5), cex.lab=1.5, cex.axis=1.4, cex.main=1.5, las=1)
res <- rep(NA,13)
for(m in 1:5){
  res <- as.matrix(cbind(res, result_sens[[m]]$summary.lincomb.derived[1:13, 4:6]))
}
res <- res[,-1]
res <- c(t(res))

x <- rep(c(0.8, 0.9, 1, 1.1, 1.2),13)
x <- x + rep(0:12, each=5)
x <- rep(x, each=3)

co <- c(1,"grey30", "grey45", "grey60", "grey75")
col= rep(rep(co, each=3), 13)
pch=rep(rep(c(4, 20, 4), 5), n) 
plot(x, exp(res), col=col, pch=pch, xaxt="n", 
  xlab="Age group", ylab="Average relative risk", main="Age effects")
axis(1, at=1:13, labels=age)
legend("bottomright", c("Sorbye & Rue: U=0.5", 
"Sorbye & Rue: U=1", 
"Sorbye & Rue: U=5", 
"WinBugs Default: Ga(0.001, 0.001) ", 
"INLA Default:        Ga(1, 0.00005)"), 
col=co, pch=20, nc=1, bty="n")

par(mar=c(4.5,5,4,0.5), cex.lab=1.5, cex.axis=1.4, las=1, cex.main=1.5)
n <- 9
res <- rep(NA,n)
for(m in 1:5){
  res <- as.matrix(cbind(res, result_sens[[m]]$summary.lincomb.derived[14:22, 4:6]))
}
res <- res[,-1]
res <- c(t(res))

x <- rep(c(0.8, 0.9, 1, 1.1, 1.2),n)
x <- x + rep(0:(n-1), each=5)
x <- rep(x, each=3)

co <- c(1,"grey30", "grey45", "grey60", "grey75")
pch=rep(rep(c(4, 20, 4), 5), n) 
col= rep(rep(co, each=3), n)
plot(x, exp(res), col=col, pch=pch, xaxt="n", 
  xlab="Period", ylab="Average relative risk", main="Period effects")
axis(1, at=1:n, labels=1998:2006)

