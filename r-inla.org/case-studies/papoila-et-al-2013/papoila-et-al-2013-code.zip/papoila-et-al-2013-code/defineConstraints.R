###############################################################################
## Functions to define constraints for the interaction effect
##
## Author: Andrea Riebler <andrea *.* riebler @ math *.* ntnu *.* no>
##
## Date: 19/07/2013
###############################################################################

## derive the reference standard deviation for the CAR modelling
library(INLA)
## get definition of rw1 and rw2
source("getprior.R")

## for the CAR and interaction effect we need the graph information
graph_path <- "SUL4.graph"
## generate a neighbourhood matrix from the graph
pgraph <- as.matrix(inla.graph2matrix(graph_path))
pgraph <- -pgraph
## INLA sets the diagonal to 1, so we need to replace it by the number
## of neighbours a node has
infograph <- inla.read.graph(graph_path)
diag(pgraph) <- infograph$nnbs

## for the Type IV interaction (structured time - structured space) effect
## we take the Kronecker product of the corresponding precision matrices
gmrf.interact <- kronecker(pgraph, rw2(J))

## calculate eigenvalues and eigenvectors
eigenInteract <- eigen(gmrf.interact,symmetric=TRUE)

## get the number of zero eigenvalues which corresponds
## to the number of constraints needed
ewInteract <- round(eigenInteract$values,digits=10)
rankDef <- sum(ewInteract==0)

## extract the eigenvectors
evInteract<-eigenInteract$vectors
nc <- ncol(evInteract)

## the last "rankdef" eigenvectors correspond to the zero
## eigenvalues and represent the constraints.
AmInteract<-t(evInteract[, (nc-rankDef+1):nc])
emInteract<-rep(0,rankDef)

## save the constraints in the form needed for INLA
extramInteract<-list(A=AmInteract,e=emInteract)

## for the Type II interaction (structured time - unstructured space) effect
## we take the Kronecker product of the corresponding precision matrices
pustruc <- diag(R)
gmrf.interact2 <- kronecker(pustruc, rw2(J))

## calculate eigenvalues and eigenvectors
eigenInteract2 <- eigen(gmrf.interact2,symmetric=TRUE)

## get the number of zero eigenvalues which corresponds
## to the number of constraints needed
ewInteract2 <- round(eigenInteract2$values,digits=10)
rankDef2 <- sum(ewInteract2==0)

## extract the eigenvectors
evInteract2<-eigenInteract2$vectors
nc2 <- ncol(evInteract2)

## the last "rankdef" eigenvectors correspond to the zero
## eigenvalues and represent the constraints.
AmInteract2<-t(evInteract2[, (nc2-rankDef2+1):nc2])
emInteract2<-rep(0,rankDef2)

## save the constraints in the form needed for INLA
extramInteract2<-list(A=AmInteract2,e=emInteract2)
