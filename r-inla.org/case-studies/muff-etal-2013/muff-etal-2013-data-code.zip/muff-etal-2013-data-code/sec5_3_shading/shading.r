##############################################################
## Measurement error in GLMMs with INLA (2013)
## by S. Muff, A. Riebler, H. Rue, P. Saner and  L. Held
##
## r-inla code for Section 5.3
## Seedling growth across different light conditions
##############################################################

library(INLA)
# > inla.version()
#
#
# INLA build date .........: Sat Jul 13 09:42:38 CEST 2013
# INLA hgid ...............: hgid: 93d466d9eaab  date: Sat Jul 13 09:42:00 2013 +0200
# INLA-program hgid .......: hgid: ef654eda81ec  date: Thu Jul 11 01:03:19 2013 +0200
# Maintainers .............: Havard Rue <hrue@math.ntnu.no>
#   : Finn Lindgren <finn.lindgren@gmail.com>
#   : Daniel Simpson <dp.simpson@gmail.com>
#   : Andrea Riebler <andrea.riebler@math.ntnu.no>
#   Web-page ................: http://www.r-inla.org
# Email support ...........: help@r-inla.org
# : r-inla-discussion-group@googlegroups.com
# Source-code .............: http://inla.googlecode.com


data <- read.table("shading_data4supp.txt", header=TRUE)
attach(data)

##############################################
# Analysis with the meb model
##############################################

n <- 60     # number of seedlings
s <- 15 	  # number of shadehouses
w <- w + rep(rnorm(s,0,1e-4),each=n/s)
individual <- 1:n # id to incorporate individual random effects

prior.beta <- c(0,0.01)
prior.tau <- c(1,0.005) 
prior.prec.u <- c(1,0.02)   

prec.tau <- 1/0.005 
prec.u <- 1/0.02        


formula <- y ~  f(w, model="meb", hyper = list(
  beta = list(
    param = prior.beta,
    fixed = FALSE
  ),
  prec.u = list(
    param = prior.prec.u,
    initial = log(prec.u),
    fixed = FALSE
  )
)) +
  z +
  f(individual, model = "iid", values = 1:n, 
      hyper = list(prec = list(
                  initial = log(prec.tau), 
                  param = prior.tau
                )
              )
    ) 

r.meb <- inla(formula, data = data.frame(y, w, z, individual),
              family = "poisson",
              control.fixed = list(
                mean.intercept = prior.beta[1], 
                prec.intercept = prior.beta[2],
                mean = prior.beta[1],
                prec = prior.beta[2]),
)
r.meb <- inla.hyperpar(r.meb)
summary(r.meb)
plot(r.meb)


##############################################
# Analysis with the copy feature
##############################################

w.red <- aggregate(w, by = list(sh), FUN = mean)[,2] 
n <- 60   # number of seedlings
s <- 15 	# number of shadehouses

prior.beta <- c(0,0.01)
prior.tau <- c(1,0.005)  
prior.prec.u <- c(1,0.02)   

prec.tau <- 1/0.005 
prec.u <- 1/0.02       


Y <- matrix(NA, n+s, 2)
Y[1:n, 1] <- y
Y[n+(1:s), 2] <- -w.red
beta.0 <- c(rep(1, n), rep(NA, s))
beta.x <- c(sh, rep(NA, s))
idx.x <- c(rep(NA, n), 1:s)
weight.x <- c(rep(NA, n), -rep(1, s))
beta.z <- c(z, rep(NA, s))
gamma <- c(1:n, rep(NA, s)) 
data.joint <- data.frame(Y, beta.0, beta.x, idx.x, weight.x, beta.z, gamma)

formula <- Y ~  beta.0 - 1 +
  f(beta.x, copy = "idx.x", 
    hyper = list(beta = list(param = prior.beta, fixed = FALSE))) +
  f(idx.x, weight.x, model = "iid", values = 1:s,
    hyper = list(prec = list(initial = -15, fixed = TRUE))) +
  beta.z +
  f(gamma, model = "iid", values = 1:n,
    hyper = list(prec = list(initial = log(prec.tau), param = prior.tau)))

r.copy <- inla(formula, data = data.joint,
               family = c("poisson", "gaussian"),
               control.family = list(
                 list(hyper = list()),
                 list(hyper = list(
                   prec = list(
                     initial=log(prec.u),
                     param = prior.prec.u,
                     fixed = FALSE)))),
               control.fixed = list(
                 mean.intercept = prior.beta[1],
                 prec.intercept = prior.beta[2],
                 mean = prior.beta[1],
                 prec = prior.beta[2])
)
r.copy <- inla.hyperpar(r.copy)
summary(r.copy)
plot(r.copy)





