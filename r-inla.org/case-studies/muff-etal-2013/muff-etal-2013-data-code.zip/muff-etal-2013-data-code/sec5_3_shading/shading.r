##############################################################
## Measurement error in GLMMs with INLA (2013)
## by S. Muff, A. Riebler, H. Rue, P. Saner and  L. Held
## (available from: http://arxiv.org/abs/1302.3065)
##
## r-inla code for Section 5.3
## Seedling growth across different light conditions
##############################################################

library(INLA)
# > inla.version()
# 
# 
# INLA build date .........: Sun Feb 10 22:03:37 CET 2013
# INLA hgid ...............: hgid: 9c49413cb16c  date: Sun Feb 10 22:02:27 2013 +0100
# INLA-program hgid .......: hgid: 9ecd509253fe  date: Mon Feb 04 09:54:45 2013 +0100
# Maintainers .............: Havard Rue <hrue@math.ntnu.no>
#                             : Finn Lindgren <finn.lindgren@gmail.com>
#                             : Daniel Simpson <dp.simpson@gmail.com>
# Web-page ................: http://www.r-inla.org
# Email support ...........: help@r-inla.org
#                             : r-inla-discussion-group@googlegroups.com
# Source-code .............: http://inla.googlecode.com

data <- read.table("shading_data.txt", header=TRUE)
attach(data)

n <- 60       # number of seedlings
s <- 15       # number of shadehouses
w <- w + rep(rnorm(s,0,1e-4),each=n/s)
individual <- 1:n # id to incorporate individual random effects

prec.u <- 4.98        # estimated value
prec.tau <- 57.83     # estimated value
prior.beta <- c(0,0.0001)
prior.prec.u <- c(100,99/prec.u)  # prior mode at prec.u
prior.tau <- c(100,99/prec.tau)   # prior mode at prec.tau

formula <- y ~  f(w, model="meb", hyper = list(
        beta = list(
            param = prior.beta,
            fixed = FALSE
        ),
        prec.u = list(
            param = prior.prec.u,
            initial = log(prec.u),
            fixed = FALSE
        )
  )) +
  z +
  f(individual, model = "iid", values = 1:n, hyper = list(prec = list(
        initial = log(prec.tau), 
        param = prior.tau
    )
     )
  ) 

r <- inla(formula, data = data.frame(y, w, z, individual),
         family = "poisson",
         control.fixed = list(
            mean.intercept = prior.beta[1], 
            prec.intercept = prior.beta[2],
            mean = prior.beta[1],
            prec = prior.beta[2]),
    )

summary(r)
plot(r)










