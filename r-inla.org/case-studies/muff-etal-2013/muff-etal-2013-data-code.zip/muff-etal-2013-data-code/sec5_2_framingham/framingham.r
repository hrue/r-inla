###################################################################
## Measurement error in GLMMs with INLA (2013)
## by S. Muff, A. Riebler, H. Rue, P. Saner and  L. Held
## (available from: http://arxiv.org/abs/1302.3065)
##
## r-inla code for Section 5.2
## Influence of systolic blood pressure on coronary heart disease
##
## CAUTION: 
############
## In the paper covariates have not been centered to make the results
## comparable to those Carrol et al (2006, Chapman & Hall, Boca Raton).
## However, this leads to running times of about one hour 
## (measured on my laptop with dual core and 2.70GHz) as the default
## parameters for the optimization have to be changed. Otherwise
## the posterior marginal for the intercept shows cyclical patterns.
##
## Here, we present the R-code using centered covariates, which 
## reduces the running time to seconds. Besides for beta_0 and 
## alpha_0 we obtain almost identical results.
###################################################################

library(INLA)
# > inla.version()
# 
# 
# INLA build date .........: Sun Feb 10 22:03:37 CET 2013
# INLA hgid ...............: hgid: 9c49413cb16c  date: Sun Feb 10 22:02:27 2013 +0100
# INLA-program hgid .......: hgid: 9ecd509253fe  date: Mon Feb 04 09:54:45 2013 +0100
# Maintainers .............: Havard Rue <hrue@math.ntnu.no>
#                             : Finn Lindgren <finn.lindgren@gmail.com>
#                             : Daniel Simpson <dp.simpson@gmail.com>
# Web-page ................: http://www.r-inla.org
# Email support ...........: help@r-inla.org
#                             : r-inla-discussion-group@googlegroups.com
# Source-code .............: http://inla.googlecode.com

data <- read.table("framingham_data.txt", header=T)
attach(data)

w1 <- w1 -mean(w1)
w2 <- w2 -mean(w2)
w <- rowMeans(cbind(w1, w2))  #the mean of w1 and w2
n <- nrow(data)  #641
Ntrials <- rep(1, n) 

varUEst <- sum((w1 - w)^2 + (w2 - w)^2)/n
varXEst <- summary(lm(w~z))$sigma^2 - varUEst
prec.u <- 1/varUEst
prec.x <- 1/varXEst

prior.prec.u <- c(n, 1/2*sum((w1 - w)^2 + (w2 - w)^2))
prior.prec.x <- c(100, 99/prec.x) # prior mode at prec.x
prior.beta <- c(0, 0.0001)

Y <- matrix(NA, 3*n, 3)
Y[1:n, 1] <- y
Y[n+(1:n), 2] <- rep(0, n)
Y[2*n+(1:n), 3] <- w

beta.0 <- c(rep(1, n), rep(NA, n), rep(NA, n))
beta.x <- c(1:n, rep(NA, n), rep(NA, n))
idx.x <- c(rep(NA, n), 1:n, 1:n)
weight.x <- c(rep(1, n), rep(-1, n), rep(1, n))
beta.z <- c(z, rep(NA, n), rep(NA, n))
alpha.0 <- c(rep(NA, n), rep(1, n), rep(NA, n))
alpha.z <- c(rep(NA, n), z, rep(NA, n))

data.joint <- data.frame(Y, beta.0, beta.x, idx.x, weight.x,
    beta.z, alpha.0, alpha.z)

formula <- Y ~  f(beta.x, copy = "idx.x",
    hyper = list(beta = list(initial = 1.91,
      param = prior.beta, fixed = FALSE))) +
  f(idx.x, weight.x, model = "iid", values = 1:n,
    hyper = list(prec = list(initial = -15, fixed = TRUE))) +
  beta.0 - 1 + beta.z + alpha.0 + alpha.z

r <- inla(formula, Ntrials = Ntrials, data = data.joint,
        family = c("binomial", "gaussian", "gaussian"),
    control.family = list(
            list(hyper = list()),
            list(hyper = list(
                prec = list(initial = log(prec.x),
                param = prior.prec.x,
                fixed = FALSE))),
            list(hyper = list(
                prec = list(initial=log(prec.u),
                param = prior.prec.u,
                fixed = FALSE)))),
    control.fixed = list(
            mean.intercept = prior.beta[1],
            prec.intercept = prior.beta[2],
                mean = prior.beta[1],
                prec = prior.beta[2])
     )

summary(r)
plot(r)



