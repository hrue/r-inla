##############################################################
## Measurement error in GLMMs with INLA (2013)
## by S. Muff, A. Riebler, H. Rue, P. Saner and  L. Held
## (available from: http://arxiv.org/abs/1302.3065)
##
## r-inla code for Section 5.1
## Inbreeding in Swiss ibex populations
##############################################################

library(INLA)
# > inla.version()
# 
# 
# INLA build date .........: Sun Feb 10 22:03:37 CET 2013
# INLA hgid ...............: hgid: 9c49413cb16c  date: Sun Feb 10 22:02:27 2013 +0100
# INLA-program hgid .......: hgid: 9ecd509253fe  date: Mon Feb 04 09:54:45 2013 +0100
# Maintainers .............: Havard Rue <hrue@math.ntnu.no>
#                             : Finn Lindgren <finn.lindgren@gmail.com>
#                             : Daniel Simpson <dp.simpson@gmail.com>
# Web-page ................: http://www.r-inla.org
# Email support ...........: help@r-inla.org
#                             : r-inla-discussion-group@googlegroups.com
# Source-code .............: http://inla.googlecode.com

data <- read.table("ibex_data.txt", header=T)
attach(data)

varYEst <- (summary(lm(y~w))$sigma^2)/2
varXEst <- var(w) - mean(1/error.prec)
 
prec.y <- 1/varYEst
prec.x <- 1/varXEst
prec.u <- 1

prior.prec.y <- c(10, 9/prec.y) # prior mode at prec.y
prior.prec.x <- c(10, 9/prec.x) # prior mode at prec.x
prior.prec.u <- c(2, 1)
prior.beta <- c(0, 0.0001)

formula <- y ~ f(w, model = "mec", scale = error.prec, hyper = list(
  beta = list(
    param = prior.beta,
    fixed = FALSE
    ),
  prec.u = list(
    param = prior.prec.u,
    initial = log(prec.u),
    fixed = FALSE
    ),
  prec.x = list(
    param = prior.prec.x,
    initial = log(prec.x),
    fixed = FALSE
    ),
  mean.x = list(
    initial = 0,
    fixed = TRUE
    )
  )
)

r <- inla(formula, data = data.frame(y, w, error.prec),
         family = "gaussian",
         control.family = list(
             hyper = list(
                prec = list(param = prior.prec.y,
                         initial = log(prec.y),
                         fixed = FALSE
                )
             )
          ),
         control.fixed = list(
           mean.intercept = prior.beta[1],
           prec.intercept = prior.beta[2]
         )
    )

r <- inla.hyperpar(r, dz = 0.5, diff.logdens = 20)

summary(r)
plot(r)


