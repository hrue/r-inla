if (Sys.getenv("USER") == "sigrunnsrbye") {
	setwd("/Users/sigrunnsrbye/Work/Dropbox/Janine and Dan/rainforest mesh")
}

if (Sys.getenv("USER") == "janine") {
setwd("/Users/janine/Dropbox/Janine and Dan/rainforest mesh")
}





library(INLA)
#inla.upgrade(testing=TRUE)
library(spatstat)
library(Matrix)

BCI = TRUE
source("utils.R")
source("functions.R")

nrow=50
ncol=100

verbose = TRUE
remote = FALSE
do.print = TRUE
fig.path = "figs"

the.call = ifelse(remote, "remote", inla.getOption("inla.call"))

##Plotting things}
## Construct greyscale palette function:
my.grey.palette = function (n,...) { return (grey.colors(n,0.95,0.05,...))}
## Use it:
my.palette = my.grey.palette

## Construct map data appropriate for easy plotting:
#mm = calc.map(map)

levelplotmap = function(..., mm) {
    panel.levelplot(...)
    panel.lines(mm$x, mm$y, col="red")
}
###

if (!BCI){
#### 1. Aporusa ##########
aporusa.data<-read.csv("aporusa.csv")
aporusa<-aporusa.data[aporusa.data$SP.CODE=="APORM1 ",]
data.x<-aporusa$x
data.y<-aporusa$y

}

if (BCI) {
#### 2. BCI #######
BCIData<-read.delim("BCIData.txt")

### Some different species...
#data<-BCIData[BCIData$sp=="beilpe",]
#data<-BCIData[BCIData$sp=="protco",]
#data<-BCIData[BCIData$sp=="protpa",]
data<-BCIData[BCIData$sp=="protte",]

#data<-BCIData[BCIData$sp=="anaxpa",]

data.x<-data$gx[is.na(data$gx)==F]
data.y<-data$gy[is.na(data$gy)==F]

soil<-read.csv("bci.block20.data.csv",dec=",")
soil.x <- soil$x
soil.y <- soil$y
}




### GRIDDED APPROACH ###
n.cells<-nrow*ncol

my.owin=owin(c(0,1000),c(0,500))
data.pp=ppp(x=data.x,y=data.y,window=my.owin)

dev.new()
#inla.squishplot(c(0,1),c(0,1),nrow/ncol)
old.ratio = par("pin")
par(pin=c(4,2))

#library(lattice)
#xyplot(data.pp$y~data.pp$x,col="black",scales = list(cex=1.5,col="black"),xlab=list(label="Easting",cex=1.5),ylab=list(label="Northing",cex=1.5),main="",aspect="iso",pch=20,cex=0.5)
 plot(matrix(c(data.pp$x,data.pp$y),nrow=data.pp$n,ncol=2),pch=20,cex=0.5,xlab="Easting",ylab="Northing",main="", cex.lab=1.5, cex.axis=1.5)
if (do.print)
    dev.copy2pdf(file=file.path(fig.path, "rainforest_data.pdf"))

par(pin=old.ratio)
#dev.new()
#plot(data.pp)
#if (do.print)
#dev.copy2pdf(file=file.path(fig.path, "rainforest_data.pdf"))

# Number of points and centres of each cell
x.grid=quadrats(my.owin,ncol,nrow)
count.grid=quadratcount(data.pp, tess=x.grid)
centre.grid=midpoints.func(my.owin,nrow,ncol)

soil.pp<-ppp(x=soil.x, y=soil.y, window=my.owin,marks=soil$P)
soil.P=func.grid.cov2(soil.pp,x.grid,centre.grid) #Assign covariate values to four neighbouring cells


### Single model for pattern ###
y=as.vector(count.grid)
i.spat=1:n.cells
j.error=1:n.cells
E=rep(100,n.cells)

# Fitting models
data = list(y = y, i.spat = i.spat,j.error=j.error,P=soil.P,E=E)
param.spat=c(62,0.005)


# Model including the soil covariate phosporus and spatial effect
formula = y ~ 1+P+f(i.spat, model="rw2d", nrow=nrow, ncol=ncol,scale.model=FALSE)#,hyper=list(theta=list(param=param.spat)),scale.model=TRUE,constr=TRUE)
#+f(j.error,model="iid")

result.grid <- inla(formula, data=data, family = "poisson",  E=E,
                    verbose = verbose, inla.call=the.call)

##r.grid= result.grid$summary.random$i.spat$mean
r.grid = (result.grid$summary.random$i.spat$mean +
          result.grid$summary.fixed["(Intercept)","mean"] +
          result.grid$summary.fixed["P","mean"]*soil.P)
r.grid.mat=matrix(r.grid,nrow,ncol)
r.grid.rot=t(r.grid.mat[nrow:1,])
range(r.grid.rot)



#######################################
#SPDE APPROACH
#######################################

loc = cbind(data.x,data.y)

#Make boundary

##loc.bnd = matrix(c(0,0, 1000,0, 1000,500, 0,500), 4, 2, byrow=TRUE)
##segm.bnd = inla.mesh.segment(loc.bnd)


# Construct mesh (regular mesh!), not meshed to points.  To change this for a new data set, just change the max.edge bit
# to an appropriate number
# (it's the largest edge length). Just run the command and plot the mesh until you get something that looks sensible.

row.x=seq(my.owin$x[1],my.owin$x[2],length=ncol)
row.y=seq(my.owin$y[1],my.owin$y[2],length=nrow)

latt = inla.mesh.lattice(x=row.x, y=row.y)
mesh <- inla.mesh.create(lattice=latt, refine=FALSE, extend=FALSE)
##mesh = inla.mesh.create(boundary = segm.bnd, refine= list(max.edge = 50, min.angle=25) )

dev.new()
plot(mesh)
if (do.print)
    dev.copy2pdf(file=file.path(fig.path, "rainforest_mesh.pdf"))
# mesh = inla.mesh.create(loc = matrix(c(soil.x,soil.y),ncol=2,byrow=FALSE),boundary = segm.bnd)

#also make a mesh for the data lattice - this is convenient.  We could Krig instead, but I cna't be bothered right now.  So instead we're going to do piecewise linear interpolation on the provided covariate information.  It shoudl be fine - the plot looks sufficiently smooth.


dat.bnd = matrix(c(10,10, 990,10, 990,490, 10,490), 4, 2, byrow=TRUE)
dat.bnd = inla.mesh.segment(dat.bnd)

mesh.data = inla.mesh.create(loc=cbind(soil$x,soil$y),boundary=dat.bnd)
covariateMatrix = inla.mesh.project(mesh.data,rbind(mesh$loc[,1:2]))$A
P.mesh = as.numeric(covariateMatrix%*%soil$P)


#Convenient definitions - number of vertices and number of observations
nV=mesh$n
nData <- length(data.x)

#Make the spde - simple non-intrinsic Matern
spde <- inla.spde2.matern(mesh, constr=TRUE,
                          B.tau = cbind(0,1),
                          B.kappa = cbind(log(sqrt(8)/2000), 0),
                          theta.prior.mean = 0,
                          theta.prior.prec = 0.001)


#See paper - we need two A matrices, one for the location of the points and one for the integration points
# (here taken to be the identity matrix)
LocationMatrix = inla.mesh.project(mesh, loc)$A
IntegrationMatrix = sparseMatrix(i=1:nV,j=1:nV,x=rep(1,nV)) #simple integration scheeme
ObservationMatrix=rBind(IntegrationMatrix,LocationMatrix) #Glue matrices together

#The integration weights (alpha in the paper)
IntegrationWeights = diag(inla.mesh.fem(mesh)$c0)
E_point_process =c(IntegrationWeights,rep(0,nData)) #Glue everything together


fake_data = c(rep(0,nV),rep(1,nData)) #Put a zero where there aren't observations and a 1 where there is a point
formula = y ~ -1 + intercept + P +  f(idx, model=spde) #Basic latent model - feel free to add covariates etc
data = list(y=fake_data,idx = c(1:nV), P = P.mesh, intercept=rep(1,nV)) #put the data in the INLA call.
#Likelihood is Poisson with Observation Matrix and appropriate value for E.
result.spde <- inla(formula, data=data, family="poisson",
                    control.predictor=list(A=ObservationMatrix),
                    E=E_point_process,
                    verbose = verbose, inla.call=the.call)


result.thespde = inla.spde.result(result.spde, "idx", spde)

#########################
#Some fancy plotting code stolen from Finn
###########################
## Prepare for plotting:

## Calculate mapping between triangulation vertices and grid points:

proj = inla.mesh.projector(mesh, dims=c(ncol,nrow))




#####################
## Plot results:
if (FALSE) {
r.idx=result.spde$summary.fixed[1] + result.spde$summary.random$idx[,"mean"]

## Map resulting posterior mean field to a grid:
plotdata1 = inla.mesh.project(proj, r.idx)
proj2 = inla.mesh.projector(mesh.data,dims=c(200,200))
plotdata2 = inla.mesh.project(proj2, result.spde$summary.fixed[2]*soil$P)
plotdata = plotdata1 + plotdata2

Acov2mesh = inla.mesh.project(mesh.data,mesh$loc)$A
r.idx=result.spde$summary.fixed[1] + result.spde$summary.random$idx[,"mean"] + result.spde$summary.fixed[2]*(Acov2mesh%*%soil$P)
plotdata = inla.mesh.project(proj,r.idx)
}


col.at = pretty(c(range(r.grid), range(plotdata)), 16)

row.x=seq(my.owin$x[1],my.owin$x[2],length=ncol)
row.y=seq(my.owin$y[1],my.owin$y[2],length=nrow)

dev.new()
bbb=(levelplot(row.values=row.x,column.values=row.y,x=r.grid.rot,
               mm=NULL,panel=levelplotmap,
               col.regions=my.palette,
               xlim=my.owin$x,ylim=my.owin$y, aspect="iso",
               contour=TRUE,at=col.at,labels=FALSE,pretty=TRUE,
               xlab="Easting",ylab="Northing"))

print(bbb)
if (do.print)
    dev.copy2pdf(file=file.path(fig.path, "rainforest_grid.pdf"))


##r.idx =  result.spde$summary.random$idx[,"mean"]
r.idx = (result.spde$summary.random$idx$mean +
          result.spde$summary.fixed["intercept","mean"] +
          result.spde$summary.fixed["P","mean"]*P.mesh)
plotdata = inla.mesh.project(proj,r.idx)

## Plot PM contours:
dev.new()
bbb = (levelplot(row.values=proj$x, column.values=proj$y, x=plotdata,
                 mm=NULL, panel=levelplotmap,
                 col.regions=my.palette,
                 xlim=range(proj$x), ylim=range(proj$y), aspect="iso",
                 contour=TRUE, at=col.at, labels=FALSE, pretty=TRUE,
                 xlab="Easting",ylab="Northing"))
print(bbb)
if (do.print)
    dev.copy2pdf(file=file.path(fig.path, "rainforest_spde.pdf"))




################################################
################################################


#Plot the effects of P
##xlim <- range(c(range(result.grid$marginals.fixed$P[,1]),
##                range(result.spde$marginals.fixed$P[,1])))
##ylim <- range(c(range(result.grid$marginals.fixed$P[,2]),
##                range(result.spde$marginals.fixed$P[,2])))
dev.new()
old.ratio = par("pin")
par(pin=c(4,2))

plot(inla.smarginal(result.spde$marginals.fixed$P),lty=1,type="l",
     ##     xlim=xlim,ylim=ylim,
     cex.lab=1.5, cex.axis=1.5,#xlim=c(-0.3,0.3),ylim=c(0,12),
     xlab="Phosphorus", ylab="")
 lines(inla.smarginal(result.grid$marginals.fixed$P),lty=2,type="l")

if (do.print)
    dev.copy2pdf(file=file.path(fig.path, "rainforest_P.pdf"))

par(pin=old.ratio)
## Compare cumulative distribution functions for the
## aggregated field reconstructions
dev.new()
plot(sort(r.grid.rot),seq(0,1,length=length(r.grid.rot)),type="l");
lines(sort(plotdata),seq(0,1,length=length(plotdata)),lty=2)
