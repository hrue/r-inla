midpoints.func=function(x.win,nrow,ncol)
{
eps=c((max(x.win$x)-min(x.win$x))/ncol/2,(max(x.win$y)-min(x.win$y))/nrow/2)

x.x=matrix(rep(seq(min(x.win$x)+eps[1],max(x.win$x)-eps[1],length=ncol),nrow),nrow,ncol,byrow=T)

x.y=matrix(rep(seq(max(x.win$y)-eps[2],min(x.win$y)+eps[2],length=nrow),ncol),nrow,ncol)

x.ppp=ppp(x.x,x.y,window=x.win)

return(x.ppp)
}


plot.cc<-function(res.cc)
{
f.ex=splinefun(res.cc[[1]],res.cc[[2]],method="natural")
r=res.cc[[1]]
mat=matrix(0,nrow=3,ncol=length(r))
for (i in 1:3)
	mat[i,]=res.cc[[(2*i)]]
matplot(r,t(mat),type="lll",lty=c(1,2,2),lwd=c(2,1,1),col=c(1),xlab="Distance d in meters",
		font=1,ylab=expression(f[cc](d)),cex.lab=1.4,cex.axis=1.4,main="")
#matplot(r,t(mat),type="lll",lty=c(1,2,2),lwd=c(2,1,1),col=c(1),xlab="Distance d in meters",
#		font=1,ylab=expression(hat(f)[cc](d)),cex.lab=1.1,cex.axis=1.1,main="")

}

im.matrix<-function (x, wrap = TRUE, xaxt = FALSE, yaxt = FALSE)
{
	#if (!is.matrix(x))
    #	stop("First argument must be a matrix")
    n = dim(x)
    y = x
    if (wrap) {
        for (j in 1:n[2]) y[1:n[1], j] = x[n[1]:1, j]}
# inla.squishplot(c(0, 1), c(0, 1), n[1]/n[2])
    image.plot(t(y), col = gray(seq(0, 1, len = 256)), bty = "n",xaxt = "n", yaxt = "n",cex.axis=2)
}


f.mean.density<-function(z,x.win)
{
grid.mean.list=by(z,x.win,FUN=function(z){mean(as.vector(z))})
grid.mean=matrix(as.numeric(grid.mean.list),ncol,nrow,byrow=T)
#grid.mean=grid.mean[ncol:1,]
return(grid.mean)
}

f.kest<-function(mid.p,x.p)
{
a=Kest(x.p)
f.est = splinefun(a$r,a$iso,method="natural")
x.dnp=nncross(mid.p,x.p)$dist
b=f.est(x.dnp)
return(b)
}

f.nn2=function(x.ppp,x.order,x.count,y.p)
{

	x.dnp2=rep(0,n.tot)
	a=nncross(x.ppp,x.order)
	for (j in 1:n.tot)
		x.dnp2[j]=nncross(x.ppp[j],x.order[-a$which[j]])$dist
	x.obs=x.ppp[x.count>0]
	x.obs.dist=nndist(x.obs,k=2)
	x.dnp2[y.p>0]=x.obs.dist
	return(x.dnp2)
}

# 7 NN-k, Exact approach

#for (j in 1:n.tot)
#{
#	x.super=superimpose(x.ppp[j],x.p)
#	x.dist=nndist(x.super,k=nk)
#	x.cov[j]=x.dist[1]
#}

# Cheating
#if (no==8)
#	x.cov=f.nnk(x.ppp,x.order,nk,x.grid,y.p) #find nearest neighbour

# Find position, nn + nk-1
f.nnk=function(x.ppp,x.order,nk,x.grid,y.p)
{
	x.nabo=nncross(x.ppp,x.order)$which
	x.point.nabo=nnwhich(x.order,k=nk)
	kn=x.point.nabo[x.nabo]
	x.vec=as.vector(x.ppp$x)
	y.vec=as.vector(x.ppp$y)
	x.cov=sqrt((x.order[kn]$x-x.vec)^2+(x.order[kn]$y-y.vec)^2)
	x.cov[y.p>0]=nndist(x.grid,k=nk)
	return(x.cov)
}


func.im.area<-function(vec,ns,index.in,bg)
{
	x.mat<-rep(bg,ns)
	x.mat[index.in]<-vec
	im.matrix(matrix(x.mat,nrow,ncol))
}

func.im.area2<-function(vec,ns,index.in,bg)
{
	x.mat<-rep(bg,ns)
	x.mat[index.in]<-vec
	inla.squishplot(c(0,1),c(0,1),nrow/ncol)
	im.matrix(matrix(x.mat,nrow,ncol))
}

#####    Various alternatives for the NN-covariate    #####

### Alt. 1: Accurate distance to nearest point outside cell

func.nn.exact<-function(x.ppp,x.p,y.count)
{
b<-nncross(x.ppp,x.p)$dist

index<-seq(1:(x.ppp$n))[y.count>0]
i.seq<-seq(1:length(index))

a<-x.ppp[y.count>0]
a.count<-y.count[y.count>0]
for (i in i.seq)
{
	pp.super<-superimpose(a[i],x.p)
	b[index[i]]<-nndist(pp.super,k=(a.count[i]+1))[1]
}
return(b)
}

### Alt. 2: Distance to nearest midpoint outside cell with observations.
func.nn=function(x.ppp,x.p,y.count)
{
a<-x.ppp[y.count>0]
b<-nncross(x.ppp,x.p)$dist
b[y.count>0]=nndist(a)
return(b)
}


### Alt. 3: Distance between all midpoints, to midpoints of cells containing points (original idea).

func.nn.mid=function(x.ppp,x.p,y.count)
{
a<-x.ppp[y.count>0]
b<-nncross(x.ppp,a)$dist

index<-seq(1:n)[b==0]
i.seq<-seq(1:a$n)

for (i in i.seq)
 	b[index[i]]<-nncross(x.ppp[index[i]],a[-i])$dist
return(b)
}

### Functions for covariates ####
# Grid covariates

####  Make routine that considers all cases: No covariate value, one cov.value, >1 cov.value in a cell. ####

func.grid.cov=function(cov.pp,x.grid,mid.p)
{
	c1.values=cov.pp$marks
	#c1.values=(c1.values-mean(c1.values))/sd(c1.values) #Standardize?
	c1.count=quadratcount(cov.pp,tess=x.grid)
	c1.mid=mid.p[c1.count>0]
	cdist=nncross(cov.pp,c1.mid)$which
	c.mean=tapply(c1.values,cdist,mean)
	c1=rep(NA,length(as.vector(c1.count)))
	c1[c1.count>0]=c.mean
	return(c1)
}

### Assign covariate value to first order neighbours
func.grid.cov2=function(cov.pp,x.grid,mid.p)
{
	c1=rep(NA,mid.p$n)
	c1.values=cov.pp$marks
	#c1.values=(c1.values-mean(c1.values))/sd(c1.values) #Standardize?
	#c1.values=(c1.values-mean(c1.values)) #Mean-centered?
	cdist=nncross(mid.p,cov.pp)$which
	c1=c1.values[cdist]
	return(c1)
}



####  Mean value of covariates in the different cells ####
# Find mean for marked pattern based on tesselations. SLOW!!!, but general.
# Needs to include NA?
func.grid.mean=function(z,x.grid) #z - point process with values of covariate as marks
{
grid.mean.list=by(z,x.grid,FUN=function(z){mean(z$marks)})
grid.mean=matrix(as.numeric(grid.mean.list),nrow,ncol,byrow=T)
return(grid.mean)
}

