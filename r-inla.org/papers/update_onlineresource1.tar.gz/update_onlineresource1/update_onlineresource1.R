#########
# Journal: Computational Statistics
# Title: A primer on disease mapping and ecological regression using INLA
# Authors: Schrödle Birgit and Leonhard Held
# Institution: University of Zurich, Switzerland
# Email: birgit.schroedle@ifspm.uzh.ch
#########

#########
# UPDATE of Online Resource 1, written on APRIL 13th, 2011
# UPDATED additional files: cox08.txt, cox.txt, switzerland.graph

### load INLA library - for installation of INLA check www.r-inla.org
library(INLA)

### Spatial disease mapping -- Model BYM1
# read UPDATED Coxiellosis data for 2008
cox.08<-read.table("cox.08.txt",header=TRUE)

# specify hyperpriors for nu and psi
prior.nu<-c(1,0.01)
prior.psi<-c(1,0.018)

# specify the formula for model BYM1 (see Section 3.2) USING THE NEW HYPERPARAMETER SPECIFICATION
f.BYM1<-Y.cox~f(region.nu,model="iid",hyper=list(prec=list(param=prior.nu)))+f(region.psi,model="besag",graph.file="switzerland.graph",hyper=list(prec=list(prior.psi)))

# run model BYM1
# strategy="laplace": use the full Laplace approximation for the approximation of the latent Gaussian field
# dic=1: compute the DIC
# cpo=1: compute the conditional predictive ordinate (CPO) and the probability integral transform (PIT) 
BYM1<-inla(f.BYM1,family="poisson",E=offset,data=cox.08,control.inla=list(strategy="laplace"),control.compute=list(dic=1,cpo=1))


### Spatio-temporal disease mapping -- Models ST1, ST2 and ST3
# read UPDATED Coxiellosis data for 2005 to 2008
cox<-read.table("cox.txt",header=TRUE)

# specify hyperpriors
prior.wishart<-c(4,1,1,0)
prior.gamma<-c(1,0.00005)


# specify and run model ST1 (see Section 3.2)
## OLD CALL: f.ST1<-Y.cox~f(region.nu,model="iid",param=prior.nu)+f(region.psi,model="besag",param=prior.psi,graph.file="switzerland.graph")+f(canton.alpha,model="2diidwishartpart0",param=prior.wishart)+f(differential.delta,time,model="2diidwishartpart1")+time.beta1 

# UPDATED CODE USING MODEL "iid2d":
# indexes for "copy"-feature:
# cox$cantons.alpha: 1-27
# cox$differential.delta: 28-54
cox$differential.delta<-cox$differential.delta+27

f.ST1<-Y.cox~f(region.nu,model="iid",hyper=list(prec=list(param=prior.nu)))+f(region.psi,model="besag",graph.file="switzerland.graph",hyper=list(prec=list(param=prior.psi)))+f(canton.alpha,model="iid2d",n=54,hyper=list(prec1=list(param=prior.wishart)))+f(differential.delta,time,copy="canton.alpha")+time.beta1

# enlarge number of function evaluation for hyperparameters: numint.maxfeval=5000000
ST1<-inla(f.ST1,family="poisson",E=offset,data=cox,control.inla=list(strategy="laplace",numint.maxfeval=5000000),control.compute=list(dic=1,cpo=1))


# specify and run model ST2 (see Section 3.3/3.4)
## OLD CALL: f.ST2<-Y.cox~f(region.nu,model="iid",param=prior.nu)+f(region.psi,model="besag",param=prior.psi,graph.file="switzerland.graph")+f(canton.alpha,model="2diidwishartpart0",param=prior.wishart)+f(differential.delta,time,model="2diidwishartpart1")+time.beta1+ncalves.beta2

# UPDATED CALL USING MODEL "iid2d":
f.ST2<-Y.cox~f(region.nu,model="iid",hyper=list(prec=list(param=prior.nu)))+f(region.psi,model="besag",graph.file="switzerland.graph",hyper=list(prec=list(param=prior.psi)))+f(canton.alpha,model="iid2d",n=54,hyper=list(prec1=list(param=prior.wishart)))+f(differential.delta,time,copy="canton.alpha")+time.beta1+ncalves.beta2

ST2<-inla(f.ST2,family="poisson",E=offset,data=cox,control.inla=list(strategy="laplace",numint.maxfeval=5000000),control.compute=list(dic=1,cpo=1))


# specify and run model ST3 (see Section 3.4)
## OLD CALL: f.ST3<-Y.cox~f(region.nu,model="iid",param=prior.nu)+f(region.psi,model="besag",param=prior.psi,graph.file="switzerland.graph")+f(canton.alpha,model="2diidwishartpart0",param=prior.wishart)+f(differential.delta,time,model="2diidwishartpart1")+time.beta1+f(ncalves.gamma,model="rw2",param=prior.gamma)

# UPDATED CALL USING MODEL "iid2d":
f.ST3<-Y.cox~f(region.nu,model="iid",hyper=list(prec=list(param=prior.nu)))+f(region.psi,model="besag",graph.file="switzerland.graph",hyper=list(prec=list(param=prior.psi)))+f(canton.alpha,model="iid2d",n=54,hyper=list(prec1=list(param=prior.wishart)))+f(differential.delta,time,copy="canton.alpha")+time.beta1+f(ncalves.gamma,model="rw2",hyper=list(prec=list(param=prior.gamma)))

ST3<-inla(f.ST3,family="poisson",E=offset,data=cox,control.inla=list(strategy="simplified.laplace",numint.maxfeval=5000000),control.compute=list(dic=1,cpo=1))


### check INLA output --> some examples
# look at the summary of the fixed effects for model ST1
ST1$summary.fixed

# look at the summary of a random effect, e.g. region.nu
ST1$summary.random$region.nu

# look at the summary of all hyperparameters
ST1$summary.hyperpar

# look at the DIC and its components
# UPDATE: DIC OBJECT HAS NOW LIST STRUCTURE
ST1$dic$dic

# look at all quantities needed to calculate the logarithmic score and a PIT histogram
ST1$cpo
ST1$pit
ST1$failure # flag: did their computation fail?

### some useful plots and functions
# plot the posterior marginal of a random effect, e.g. the first component of region.nu
plot(ST1$marginals.random$region.nu[[1]][,1], ST1$marginals.random$region.nu[[1]][,2],type="l",xlab="",ylab="",main=expression(nu[1]))

# plot the posterior marginal of a hyperparameter, e.g. the precision of nu (see summary on page 12)
plot(ST1$marginals.hyperpar[[1]][,1],ST1$marginals.hyperpar[[1]][,2],type="l",xlab="",ylab="",main=expression(tau[nu]))
# you can use the function inla.hyperpar(inla-object) to obtain more precise approximations for the posterior marginals of single hyperparameters

# plot the result for a nonparametric explanatory variable, e.g. ncalves.gamma, including (pointwise) confidence bands
# be aware: the values of ncalves.gamma have be scaled using the factor 2.74 before the analysis, so that the mean difference between consecutive values is 1 (see Section 3.4) 
plot(ST3$summary.random$ncalves.gamma[,1]/2.74,ST3$summary.random$ncalves.gamma[,2],type="l",xlab="",ylab="",ylim=c(-4,4),main=expression(gamma))
lines(ST3$summary.random$ncalves.gamma[,1]/2.74,ST3$summary.random$ncalves.gamma[,4],lty=2)
lines(ST3$summary.random$ncalves.gamma[,1]/2.74,ST3$summary.random$ncalves.gamma[,6],lty=2)
