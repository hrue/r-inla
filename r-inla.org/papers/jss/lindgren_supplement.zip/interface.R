### R code from vignette source 'interface.Rtex'

###################################################
### code chunk number 1: interface.Rtex:1-4
###################################################
require(INLA)
set.seed(12345L)
inla.qsample(n=1, Matrix(1,1,1), seed=12345L)


###################################################
### code chunk number 2: interface.Rtex:15-41
###################################################
my.levelplot <-
  function(proj, values,
           col.regions=grey.colors(64, 1, 0),
           aspect="fill",
           contour=TRUE, labels=FALSE,
           xlim=range(proj$x), ylim=range(proj$y),
           ...) {
    z = inla.mesh.project(proj, values)
    print(levelplot(
      row.values=proj$x, column.values=proj$y, x=z,
      xlim=xlim, ylim=ylim,
      col.regions=col.regions, aspect=aspect,
      contour=contour, labels=labels, ...))
}
lattice.to.plot <- function(latt, projection, skip=10) {
  loc = inla.mesh.map(latt$loc, projection=projection, inverse=FALSE)
  mat1 = matrix(loc[,1], nrow=latt$dims[1], ncol=latt$dims[2])
  mat2 = matrix(loc[,2], nrow=latt$dims[1], ncol=latt$dims[2])
  hskip = seq(1,latt$dims[1],skip)
  vskip = seq(1,latt$dims[2],skip)
  return(rbind(
    cbind(as.vector(rbind(cbind(mat1[,vskip], NA), NA)),
          as.vector(rbind(cbind(mat2[,vskip], NA), NA))),
    cbind(as.vector(rbind(cbind(t(mat1[hskip,]), NA), NA)),
          as.vector(rbind(cbind(t(mat2[hskip,]), NA), NA)))))
}


###################################################
### code chunk number 3: interface.Rtex:56-59 (eval = FALSE)
###################################################
## source("http://www.math.ntnu.no/inla/givemeINLA.R")
## library(INLA)
## inla.upgrade(testing=TRUE)


###################################################
### code chunk number 4: interface.Rtex:88-103
###################################################
mesh1d.basis.plot = function(mesh, n, idx=1:mesh$m, w=NULL, add=FALSE, ...) {
  x = seq(mesh$interval[1], mesh$interval[2], length=n)
  A = inla.mesh.1d.A(mesh, x)
  if (is.null(w)) {
    if (!add)
      plot(x=0, type="n", xlim = mesh$interval, ylim = range(A), ...)
    for (k in idx)
      lines(x, A[,k])
  } else {
    f = A %*% w
    if (!add)
      plot(x=0,type="n", xlim = mesh$interval, ylim = range(f), ...)
    lines(x, f)
  }
}


###################################################
### code chunk number 5: interface.Rtex:116-127 (eval = FALSE)
###################################################
## inla.mesh.create(loc=, ...)
## inla.mesh.create(loc=, tv=, ...)
## inla.mesh.create(lattice=, ...)
## inla.mesh.create(globe=, ...)
## inla.delaunay(loc=)
## inla.mesh.2d(loc=, ...)
## inla.mesh.1d(loc=, ...)
## 
## inla.sp2segment(sp)
## inla.mesh.segment(loc, ...)
## inla.nonconvex.hull(loc, ...)


###################################################
### code chunk number 6: interface.Rtex:151-158
###################################################
m = 50
points = matrix(runif(m*2), m, 2)
mesh = inla.mesh.2d(
  loc=points,
  cutoff=0.05,
  offset=c(0.1, 0.4),
  max.edge=c(0.05, 0.5) )


###################################################
### code chunk number 7: mesh1
###################################################
plot(mesh, main="")
points(points)


###################################################
### code chunk number 8: mesh3
###################################################
bnd = inla.nonconvex.hull(points, convex=0.12)
mesh = inla.mesh.2d(
  boundary=bnd,
  cutoff=0.05,
  max.edge=c(0.1) )
plot(mesh, main="")


###################################################
### code chunk number 9: mesh2
###################################################
lines(bnd, add=FALSE)
points(points)


###################################################
### code chunk number 10: interface.Rtex:197-203
###################################################
bnd = inla.nonconvex.hull(points, convex=0.12)
mesh = inla.mesh.2d(
  boundary=bnd,
  cutoff=0.05,
  offset = c(1, 0.5),
  max.edge=c(0.1, 0.5) )


###################################################
### code chunk number 11: mesh4
###################################################
plot(mesh, main="")


###################################################
### code chunk number 12: interface.Rtex:232-233 (eval = FALSE)
###################################################
## A = inla.spde.make.A(mesh, loc=points)


###################################################
### code chunk number 13: interface.Rtex:259-260
###################################################
spde = inla.spde2.matern(mesh, alpha=2)


###################################################
### code chunk number 14: interface.Rtex:273-284
###################################################
sigma0 = 1 ## Field std.dev. for theta=0
size = min(c(diff(range(mesh$loc[,1])),
             diff(range(mesh$loc[,2]))))
range0 = size/5 ## A fifth of the approximate domain width.
kappa0 = sqrt(8)/range0
tau0 = 1/(sqrt(4*pi)*kappa0*sigma0)
spde = inla.spde2.matern(mesh,
  B.tau=cbind(log(tau0), -1, -1),
  B.kappa=cbind(log(kappa0), 0, -1),
  theta.prior.mean=c(0,0),
  theta.prior.prec=c(0.1, 1) )


###################################################
### code chunk number 15: interface.Rtex:328-330
###################################################
truevar = (3*sigma0)^2
truerange = range0


###################################################
### code chunk number 16: interface.Rtex:332-333
###################################################
Q = inla.spde.precision(spde, theta=c(log(3), 0))


###################################################
### code chunk number 17: interface.Rtex:336-337 (eval = FALSE)
###################################################
## x = inla.qsample(n=2, Q)


###################################################
### code chunk number 18: interface.Rtex:340-341
###################################################
x = inla.qsample(n=2, Q, seed=123L)


###################################################
### code chunk number 19: interface.Rtex:353-354 (eval = FALSE)
###################################################
## x = inla.qsample(n=2, Q, constr=spde$f$extraconstr)


###################################################
### code chunk number 20: interface.Rtex:371-374
###################################################
plot(mesh)
plot(mesh, rgl=TRUE)
lines(mesh$segm$bnd, mesh$loc, add=FALSE)


###################################################
### code chunk number 21: interface.Rtex:383-386
###################################################
plot(mesh, rgl=TRUE, col=x[,1],
     color.palette=function(n) grey.colors(n, 1, 0),
     draw.edges=FALSE, draw.segments=TRUE, draw.vertices=FALSE)


###################################################
### code chunk number 22: interface.Rtex:392-394
###################################################
proj = inla.mesh.projector(mesh, dims=c(100, 100))
image(proj$x, proj$y, inla.mesh.project(proj, field=x[,1]))


###################################################
### code chunk number 23: sample1
###################################################
my.levelplot(proj, x[,1], at=pretty(x, 16), aspect="iso",
      xlim=c(0,1), ylim=c(0,1),
      xlab="", ylab="", main="")


###################################################
### code chunk number 24: sample2
###################################################
my.levelplot(proj, x[,2], at=pretty(x, 16), aspect="iso",
      xlim=c(0,1), ylim=c(0,1),
      xlab="", ylab="", main="")


###################################################
### code chunk number 25: interface.Rtex:419-421
###################################################
latt=inla.mesh.lattice(x=seq(-180,180,1),
       y=seq(-90,90,1)*(1-1e-8), units="longlat")


###################################################
### code chunk number 26: interface.Rtex:425-432
###################################################
print(contourplot(x=matrix(c(0,0,0,0),2,2),
    row.values=c(0,1), column.values=c(0,1),
    xlim=c(-180,180), ylim=c(-90,90),
    aspect=1/2, xlab="Longitude",ylab="Latitude"))
trellis.focus("panel", 1, 1, highlight=FALSE)
print(llines(lattice.to.plot(latt,"longlat"), col=1))
trellis.unfocus()


###################################################
### code chunk number 27: interface.Rtex:435-442
###################################################
print(contourplot(x=matrix(c(0,0,0,0),2,2),
    row.values=c(0,1), column.values=c(0,1),
    xlim=c(-180,180), ylim=c(-1,1),
    aspect=1/2, xlab="Longitude",ylab=""))
trellis.focus("panel", 1, 1, highlight=FALSE)
print(llines(lattice.to.plot(latt,"longsinlat"), col=1))
trellis.unfocus()


###################################################
### code chunk number 28: interface.Rtex:445-452
###################################################
print(contourplot(x=matrix(c(0,0,0,0),2,2),
    row.values=c(0,1), column.values=c(0,1),
    xlim=c(-2,2), ylim=c(-1,1),
    aspect=1/2, xlab="",ylab=""))
trellis.focus("panel", 1, 1, highlight=FALSE)
print(llines(lattice.to.plot(latt,"mollweide"), col=1))
trellis.unfocus()


###################################################
### code chunk number 29: interface.Rtex:460-467
###################################################
mesh2 = inla.mesh.create(globe=10)
spde2 = inla.spde2.matern(mesh2)
Q2 = inla.spde2.precision(spde2, theta=c(0, -1))
x2 = inla.qsample(n=1, Q2, seed=1234L)[,1]
proj2a = inla.mesh.projector(mesh2, projection="longlat", dims=c(361,181))
proj2b = inla.mesh.projector(mesh2, projection="longsinlat", dims=c(361,181))
proj2c = inla.mesh.projector(mesh2, projection="mollweide", dims=c(361,181))


###################################################
### code chunk number 30: proj2a
###################################################
my.levelplot(proj2a, x2, at=pretty(x2, 16), aspect=1/2,
      xlab="Longitude", ylab="Latitude", main="Lon-Lat projection")
trellis.focus("panel", 1, 1, highlight=FALSE)
print(llines(lattice.to.plot(latt, "longlat", 30), col=1))
trellis.unfocus()


###################################################
### code chunk number 31: proj2b
###################################################
my.levelplot(proj2b, x2, at=pretty(x2, 16), aspect=1/2,
      xlab="Longitude", ylab="", main="Lon-sin(Lat) projection")
trellis.focus("panel", 1, 1, highlight=FALSE)
print(llines(lattice.to.plot(latt, "longsinlat", 30), col=1))
trellis.unfocus()


###################################################
### code chunk number 32: proj2c
###################################################
my.levelplot(proj2c, x2, at=pretty(x2, 16), aspect=1/2,
      xlab="", ylab="", main="Mollweide projection")
trellis.focus("panel", 1, 1, highlight=FALSE)
print(llines(lattice.to.plot(latt, "mollweide", 30), col=1))
trellis.unfocus()


###################################################
### code chunk number 33: interface.Rtex:559-565 (eval = FALSE)
###################################################
## stack = inla.stack(data=list(...),
##                    A=list(A1, A2, ...),
##                    effects=list(list(...),
##                                 list(...),
##                                 ...),
##                    tag=...)


###################################################
### code chunk number 34: interface.Rtex:570-571 (eval = FALSE)
###################################################
## stack = inla.stack(stack1, stack2, ...)


###################################################
### code chunk number 35: interface.Rtex:616-620
###################################################
A = inla.spde.make.A(mesh,
                     loc = points,
                     index = rep(1:m, times=2),
                     repl = rep(1:2, each=m) )


###################################################
### code chunk number 36: interface.Rtex:638-641
###################################################
x = as.vector(x)
covariate = rnorm(m*2)
y = 5 + covariate*2 + as.vector(A %*% x) + rnorm(m*2)*0.1


###################################################
### code chunk number 37: interface.Rtex:666-669
###################################################
mesh.index = inla.spde.make.index(name="field",
                                  n.spde=spde$n.spde,
                                  n.repl=2)


###################################################
### code chunk number 38: interface.Rtex:678-683
###################################################
st.est = inla.stack(data=list(y=y),
                    A=list(A, 1),
                    effects=list(c(mesh.index, list(intercept=1)),
                                 list(cov=covariate)),
                    tag="est")


###################################################
### code chunk number 39: interface.Rtex:703-707
###################################################
st.pred = inla.stack(data=list(y=NA),
                     A=list(1),
                     effects=list(c(mesh.index, list(intercept=1))),
                     tag="pred")


###################################################
### code chunk number 40: interface.Rtex:711-712
###################################################
stack = inla.stack(st.est, st.pred)


###################################################
### code chunk number 41: interface.Rtex:743-750
###################################################
formula =
  y ~ -1 + intercept + cov + f(field, model=spde, replicate=field.repl)
inla.result = inla(formula,
                   data=inla.stack.data(stack, spde=spde),
                   family="normal",
                   control.predictor=list(A=inla.stack.A(stack),
                                          compute=TRUE))


###################################################
### code chunk number 42: postrange
###################################################
result = inla.spde2.result(inla.result, "field", spde)
plot(result[["marginals.range.nominal"]][[1]],
     main="Nominal range, posterior density")


###################################################
### code chunk number 43: postvar
###################################################
plot(result[["marginals.variance.nominal"]][[1]],
     main="Nominal variance, posterior density")


###################################################
### code chunk number 44: interface.Rtex:782-786
###################################################
index = inla.stack.index(stack, "pred")$data
linpred.mean = inla.result[["summary.linear.predictor"]]$mean
image(proj$x, proj$y, inla.mesh.project(proj,
      linpred.mean[index[mesh.index$field.repl==1]]))


###################################################
### code chunk number 45: interface.Rtex:788-790
###################################################
index.est = inla.stack.index(stack, "est")$data
plot(inla.result$summary.fitted.values$mean[index.est], y)


###################################################
### code chunk number 46: predmean
###################################################
linpred.mean = inla.result[["summary.linear.predictor"]]$mean
xplot = linpred.mean[index[mesh.index$field.repl==1]]
my.levelplot(proj, xplot, at=pretty(xplot, 16), aspect="iso",
      xlab="", ylab="", main="", xlim=c(0,1), ylim=c(0,1))
trellis.focus("panel", 1, 1, highlight=FALSE)
print(lpoints(points, col=1))
trellis.unfocus()


###################################################
### code chunk number 47: predsd
###################################################
linpred.sd = inla.result[["summary.linear.predictor"]]$sd
xplot = linpred.sd[index[mesh.index$field.repl==1]]
my.levelplot(proj, xplot, at=pretty(xplot, 10), aspect="iso",
      xlab="", ylab="", main="", xlim=c(0,1), ylim=c(0,1))
trellis.focus("panel", 1, 1, highlight=FALSE)
print(lpoints(points, col=1))
trellis.unfocus()


