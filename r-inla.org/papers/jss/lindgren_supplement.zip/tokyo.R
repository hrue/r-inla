### R code from vignette source 'tokyo.Rtex'

###################################################
### code chunk number 1: tokyo.Rtex:1-3
###################################################
options(prompt = "R> ", continue = "+  ", width = 70, useFancyQuotes = FALSE)
require("INLA")


###################################################
### code chunk number 2: tokyo.Rtex:25-28
###################################################
data("Tokyo")
knots = seq(1, 367, length=25)
mesh = inla.mesh.1d(knots, interval=c(1, 367), degree=2, boundary="cyclic")


###################################################
### code chunk number 3: tokyo.Rtex:32-35
###################################################
sigma0 = 1
kappa0 = 1e-3
tau0 = 1/(4*kappa0^3*sigma0^2)^0.5


###################################################
### code chunk number 4: tokyo.Rtex:38-42
###################################################
spde = inla.spde2.matern(mesh, constr=FALSE,
                         B.tau = cbind(log(tau0), 1),
                         B.kappa = cbind(log(kappa0), 0),
                         theta.prior.prec = 1e-4)


###################################################
### code chunk number 5: tokyo.Rtex:45-58
###################################################
A = inla.spde.make.A(mesh, loc=Tokyo$time)
time.index = inla.spde.make.index("time", n.spde=spde$n.spde)
stack = inla.stack(data=list(y = Tokyo$y, link=1, Ntrials=Tokyo$n),
                   A=list(A),
                   effects=list(time.index),
                   tag="est")
formula = y ~ -1 + f(time, model=spde)
data = inla.stack.data(stack)
result = inla(formula, family="binomial", data=data,
              Ntrials=data$Ntrials,
              control.predictor=list(A=inla.stack.A(stack),
                                     link=data$link,
                                     compute=TRUE))


###################################################
### code chunk number 6: tokyo
###################################################
time = 1:366
index = inla.stack.index(stack, "est")$data
plot(Tokyo$time, Tokyo$y/Tokyo$n, xlab="Day", ylab="Probability")
lines(time, result$summary.fitted.values$mean[index])
lines(time, result$summary.fitted.values$"0.025quant"[index], lty=2)
lines(time, result$summary.fitted.values$"0.975quant"[index], lty=2)


###################################################
### code chunk number 7: tokyo.Rtex:70-73
###################################################
## Residuals for cumulative counts:
inla.dev.new()
plot(time, cumsum(Tokyo$y/Tokyo$n)-cumsum(result$summary.fitted.values$mean[index]))


