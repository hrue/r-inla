### R code from vignette source 'examples.Rtex'

###################################################
### code chunk number 1: examples.Rtex:1-5
###################################################
options(prompt = "R> ", continue = "+  ", width = 70, useFancyQuotes = FALSE)
require("INLA")
set.seed(12345L)
inla.qsample(n=1, Matrix(1,1,1), seed=12345L)


###################################################
### code chunk number 2: examples.Rtex:34-44 (eval = FALSE)
###################################################
## mesh1 = inla.mesh.1d(loc=seq(0, 100, length=11), degree=2, boundary="free")
## mesh2 = inla.mesh.2d(...)
## spde = inla.spde2.matern(mesh2, alpha=2, ...)
## index = inla.spde.make.index("space", n.spde=spde$n.spde, n.group=mesh1$m)
## formula = y ~ -1 + f(space, model=spde, group=space.group,
##                      control.group=list(model="ar1"))
## A = inla.spde.make.A(mesh2, loc=station.loc,
##                      index=station.id, group=time,
##                      group.mesh=mesh1)
## stack = inla.stack(data = list(y=y), A = list(A), effects = list(index))


###################################################
### code chunk number 3: examples.Rtex:56-67 (eval = FALSE)
###################################################
## stack1 = inla.stack(data=list(Y=cbind(y1, NA), link=1, N=N1), ...)
## stack2 = inla.stack(data=list(Y=cbind(NA, y2), link=2, E=E2), ...)
## stack = inla.stack(stack1, stack2)
## data = inla.stack.data(stack)
## formula = Y ~ ...
## result = inla(formula, data=data, family = c("binomial", "poisson"),
##               Ntrials = data$N,
##               E = data$E,
##               control.predictor(A=inla.stack.A(stack),
##                                 link=data$link,
##                                 compute=TRUE))


